function ButtonPress(){
    document.getElementById("error").innerHTML = "Uh oh! Try again later.";
}
document.addEventListener("DOMContentLoaded", function() {
    function updateDate(){
        const now = new Date()
        const currentTime = now.toLocaleString();

        document.querySelector('#datetime').textContent = currentTime;
        }
        setInterval(updateDate, 1)
      });